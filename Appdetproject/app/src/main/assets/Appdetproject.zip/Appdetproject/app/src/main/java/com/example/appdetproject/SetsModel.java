package com.example.appdetproject;

public class SetsModel {

    String setName;

    public SetsModel(String setName) {
        this.setName = setName;
    }

    public String getSetName() {
        return setName;
    }

    public void setSetName(String setName) {
        this.setName = setName;
    }
}
