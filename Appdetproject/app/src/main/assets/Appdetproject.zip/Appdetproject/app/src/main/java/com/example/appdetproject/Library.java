package com.example.appdetproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class Library extends AppCompatActivity {


    ArrayList<SetsModel> list;
    SetsAdapter adapter;
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activitty_library);


        recyclerView = findViewById(R.id.recyclerView);
        list = new ArrayList<>();
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        list.add(new SetsModel("SET - 1"));
        list.add(new SetsModel("SET - 2"));
        list.add(new SetsModel("SET - 3"));
        list.add(new SetsModel("SET - 4"));
        list.add(new SetsModel("SET - 5"));

        adapter = new SetsAdapter(list, this );
        recyclerView.setAdapter(adapter);
    }
}